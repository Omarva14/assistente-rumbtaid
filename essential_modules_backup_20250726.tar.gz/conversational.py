# conversational.py - VERSIONE FINALE DEFINITIVA E STABILE
import asyncio
import websockets
import json
import base64
import logging
import sounddevice as sd
import numpy as np
import re
import time
import httpx
from typing import Any, Optional

import config
from tools import spotify_tools

logger = logging.getLogger("conversational")

try:
    B64_SILENCE_20MS = config.B64_SILENCE_20MS
except AttributeError:
    logger.critical("Errore critico: B64_SILENCE_20MS non trovato in config.py.")
    B64_SILENCE_20MS = "AQAAAAAA//8AAAEAAAAAAAAAAAAAAAAA//8AAP///////wAAAQD//wAAAQAAAAAAAQD//wAA//8AAAAAAAAAAAEAAAD//wAAAAAAAAAAAAAAAAAAAAAAAP//AAAAAAAA/////wAAAAABAAAAAQAAAAEAAAD//wAAAAAAAP//AAAAAAAAAQAAAAEAAAAAAAEAAAAAAAAAAAAAAAAA////////AQD//wAA//8AAAAA//8AAAAAAAAAAAAAAAAAAP//AQAAAAAA/////wEAAAD//wAA//8AAAAAAAABAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAA//8AAAAA//8BAAAAAAABAAAAAAD//wAAAQAAAAAAAAAAAAAA//////////8AAAAAAAABAAAAAAAAAAAAAAAAAP//AAABAAAAAAAAAAAAAQAAAAAA//8AAAAAAAAAAAAAAAAAAAAAAAD//wAAAAD//wAAAQAAAAEA//8AAAAA//8AAAAAAAAAAAEAAAAAAP//AAD//wAAAAD//wAAAAAAAAAAAQAAAAAAAAAAAAAAAAABAAEAAAAAAAAAAQD//wEAAAAAAP//AQABAAAAAAAAAAAAAAAAAP//AAAAAAAAAAAAAAAA//8AAP//AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAABAAAAAAAAAAAAAAD//wAAAAD/////AAAAAAAAAAAAAAAAAAAAAAAA//8AAAAA//8AAAEAAAAAAP//AAABAAAAAAAAAAAAAAAAAP//AAAAAP////8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAAABAA=="

class ConversationalAgent:
    def __init__(self, injection_queue: asyncio.Queue, spotify_polling_queue: asyncio.Queue, text_only_mode: bool = False):
        self.api_key = config.ELEVEN_API_KEY
        self.agent_id = config.ELEVEN_AGENT_ID
        self.websocket_connect_timeout = config.ELEVEN_WEBSOCKET_TIMEOUT

        self.input_rate = 16000
        self.output_samplerate = 16000

        self.stop_event = asyncio.Event()
        self.user_can_speak = asyncio.Event()
        
        self.injection_queue = injection_queue
        self.spotify_polling_queue = spotify_polling_queue
        
        self.text_only_mode = text_only_mode
        self.request_lock = asyncio.Lock()

    async def _get_signed_websocket_url(self) -> str:
        logger.info(f"Richiesta di signed URL per agent_id: {self.agent_id}")
        url = f"https://api.elevenlabs.io/v1/convai/conversation/get-signed-url?agent_id={self.agent_id}"
        headers = {"xi-api-key": self.api_key}
        async with httpx.AsyncClient(timeout=10) as client:
            try:
                response = await client.get(url, headers=headers)
                response.raise_for_status()
                signed_url = response.json().get("signed_url")
                if not signed_url: raise ValueError("Signed URL non ricevuto.")
                logger.info("Signed URL ottenuto con successo.")
                return signed_url
            except Exception as e:
                logger.critical(f"Errore ottenimento signed URL: {e}", exc_info=True)
                raise

    async def _play_chunk(self, audio_chunk_bytes: bytes):
        loop = asyncio.get_running_loop()
        try:
            audio_data = np.frombuffer(audio_chunk_bytes, dtype=np.int16)
            if audio_data.size > 0:
                await loop.run_in_executor(None, sd.play, audio_data, self.output_samplerate)
                await loop.run_in_executor(None, sd.wait)
        except Exception as e:
            logger.error(f"Errore riproduzione chunk: {e}")

    async def _handle_agent_messages(self, websocket: websockets.WebSocketClientProtocol):
        logger.info("In ascolto per le risposte dell'agente...")
        try:
            async for message_str in websocket:
                if self.stop_event.is_set(): break
                data = json.loads(message_str)
                msg_type = data.get('type')
                logger.debug(f"[Agente] Ricevuto: {msg_type}")

                if msg_type == 'conversation_initiation_metadata':
                    self.user_can_speak.set()
                    logger.info(">> Turno dell'utente. Microfono attivo.")
                
                elif msg_type == 'user_transcript':
                    logger.info(f"✅ Trascrizione Utente: '{data.get('user_transcription_event', {}).get('user_transcript', '')}'")
                
                elif msg_type == 'agent_response':
                    if text := data.get('agent_response_event', {}).get('agent_response', ''): 
                        logger.info(f"📝 Testo Risposta Agente: '{text}'")
                    self.user_can_speak.set()
                    if self.request_lock.locked():
                        self.request_lock.release()
                        logger.info("LOCK RILASCIATO: Agente pronto per nuova richiesta iniettata.")
                    logger.info(">> Agente ha finito di rispondere. Microfono attivo.")
                
                elif msg_type == 'audio':
                    self.user_can_speak.clear()
                    if audio_chunk_b64 := data.get('audio_event', {}).get('audio_base_64'):
                        await self._play_chunk(base64.b64decode(audio_chunk_b64))

                elif msg_type == 'client_tool_call':
                    await self.handle_tool_call(websocket, data.get('client_tool_call', {}))
                
                elif msg_type == 'ping':
                     if event_id := data.get('ping_event', {}).get('event_id'):
                        await websocket.send(json.dumps({"type": "pong", "event_id": event_id}))

        except websockets.exceptions.ConnectionClosed as e:
            logger.warning(f"Connessione WebSocket chiusa: {e.code}")
            self.stop_event.set()
        except Exception as e:
            logger.error(f"Errore in _handle_agent_messages: {e}", exc_info=True)
            self.stop_event.set()

    async def handle_tool_call(self, websocket: websockets.WebSocketClientProtocol, tool_call: dict):
        tool_name = tool_call.get('tool_name')
        tool_params = tool_call.get('parameters', {})
        tool_call_id = tool_call.get('tool_call_id')
        logger.info(f"Esecuzione tool: '{tool_name}' con parametri: {tool_params}")
        try:
            tool_function = getattr(spotify_tools, tool_name)
            import inspect
            if 'spotify_polling_queue' in inspect.signature(tool_function).parameters:
                 tool_result = await tool_function(**tool_params, spotify_polling_queue=self.spotify_polling_queue)
            else:
                 tool_result = await tool_function(**tool_params)
            is_error = tool_result.get("status") != "success"
        except Exception as e:
            logger.error(f"Eccezione tool '{tool_name}': {e}", exc_info=True)
            tool_result = {"status": "error", "message": f"Errore interno: {e}"}
            is_error = True
        response_msg = {"type": "client_tool_result", "tool_call_id": tool_call_id, "result": json.dumps(tool_result), "is_error": is_error}
        await websocket.send(json.dumps(response_msg))
        logger.info(f"Risultato tool '{tool_name}' inviato. is_error: {is_error}")

    async def _listen_for_injections(self, websocket: websockets.WebSocketClientProtocol):
        while not self.stop_event.is_set():
            try:
                injection_data = await self.injection_queue.get()
                await self.request_lock.acquire()
                logger.info("LOCK ACQUISITO: Elaborazione richiesta iniettata.")
                
                injected_text = injection_data.get("text", "")
                logger.info(f"💉 Iniezione a Eleven Labs: '{injected_text}'")
                
                self.user_can_speak.clear()
                
                await websocket.send(json.dumps({"type": "user_message", "text": injected_text}))
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Errore in _listen_for_injections: {e}", exc_info=True)
                if self.request_lock.locked(): self.request_lock.release()
                self.stop_event.set()

    async def _stream_user_audio(self, websocket: websockets.WebSocketClientProtocol):
        if self.text_only_mode:
            logger.info("Modalità solo testo attiva. Stream audio da microfono disabilitato.")
            return

        audio_queue = asyncio.Queue(maxsize=50) # Coda più grande per gestire i picchi di dati
        main_loop = asyncio.get_running_loop()

        def audio_callback(indata: np.ndarray, frames: int, time_info: Any, status: Any):
            if status:
                main_loop.call_soon_threadsafe(logger.warning, f"Errore callback audio: {status}")
            
            # --- SOLUZIONE DEFINITIVA AL QueueFull ---
            # Inserisce dati nella coda solo se l'utente può parlare E se c'è spazio.
            # Altrimenti, scarta silenziosamente il pacchetto audio per prevenire l'errore.
            if self.user_can_speak.is_set():
                try:
                    main_loop.call_soon_threadsafe(audio_queue.put_nowait, indata.copy())
                except asyncio.QueueFull:
                    pass # Ignora l'errore e scarta il chunk, prevenendo il crash.

        logger.info(f"Avvio stream audio utente a {self.input_rate} Hz...")
        try:
            with sd.InputStream(samplerate=self.input_rate, channels=1, dtype='int16', callback=audio_callback, blocksize=int(self.input_rate * 0.02)):
                while not self.stop_event.is_set():
                    if self.user_can_speak.is_set():
                        try:
                            chunk_np = await asyncio.wait_for(audio_queue.get(), timeout=0.5)
                            await websocket.send(json.dumps({
                                "type": "user_audio_chunk",
                                "user_audio_chunk": base64.b64encode(chunk_np.tobytes()).decode('utf-8')
                            }))
                        except asyncio.TimeoutError:
                            continue
                    else:
                        await asyncio.sleep(0.05)
        except Exception as e:
            logger.critical(f"Errore critico stream audio: {e}", exc_info=True)
            self.stop_event.set()
        finally:
            logger.info("Stream audio utente terminato.")

    def stop(self):
        if not self.stop_event.is_set():
            self.stop_event.set()
            logger.info("Segnale di stop inviato al ConversationalAgent.")

    async def start(self):
        logger.info("🚀 Avvio del ConversationalAgent...")
        max_retries = 3
        current_retry = 0
        while current_retry <= max_retries and not self.stop_event.is_set():
            try:
                ws_connection_url = await self._get_signed_websocket_url()
                logger.info("Tentativo di connessione WebSocket...")
                async with websockets.connect(ws_connection_url, open_timeout=20, max_size=None) as websocket:
                    logger.info("Connessione WebSocket stabilita.")
                    init_message = {
                        "type": "conversation_initiation_client_data",
                        "conversation_config_override": {
                            "tts": {
                                "output_format": f"pcm_{self.output_samplerate}",
                                "voice_settings": {
                                    "stability": 0.75,
                                    "similarity_boost": 0.9,
                                    "style": 0.0,
                                    "use_speaker_boost": False
                                }
                            },
                            "generation_config": {"chunk_length_schedule": [50, 90, 120, 200]},
                            "model_id": "eleven_turbo_v2"
                        }
                    }
                    await websocket.send(json.dumps(init_message))
                    
                    tasks_to_gather = [
                        self._handle_agent_messages(websocket),
                        self._listen_for_injections(websocket)
                    ]
                    if not self.text_only_mode:
                        tasks_to_gather.append(self._stream_user_audio(websocket))
                    
                    await asyncio.gather(*tasks_to_gather)
                    
                break
            except Exception as e:
                current_retry += 1
                logger.error(f"Errore nel ciclo principale (tentativo {current_retry}/{max_retries}): {e}", exc_info=True)
                if current_retry <= max_retries: await asyncio.sleep(2 ** current_retry)
                else: self.stop_event.set()
        
        logger.info("ConversationalAgent ha terminato le sue operazioni.")
