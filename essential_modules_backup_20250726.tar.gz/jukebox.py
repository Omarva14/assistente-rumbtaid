# jukebox.py - VERSIONE FINALE E ROBUSTA
import asyncio
import logging
from typing import Optional
import spotipy

from tools.spotify_tools.auth import get_spotify_client, _update_active_device

logger = logging.getLogger("jukebox")

class Jukebox:
    def __init__(self, injection_queue: asyncio.Queue, spotify_polling_queue: asyncio.Queue, sp_client: spotipy.Spotify):
        self.injection_queue = injection_queue
        self.spotify_polling_queue = spotify_polling_queue
        self.sp = sp_client
        self.current_playing_uri: Optional[str] = None
        self.stop_event = asyncio.Event()

    async def monitor_playback(self):
        logger.info("🎶 Jukebox in attesa di canzoni da monitorare...")

        while not self.stop_event.is_set():
            try:
                # Controlla se c'è un nuovo brano da monitorare
                if not self.spotify_polling_queue.empty():
                    self.current_playing_uri = await self.spotify_polling_queue.get()
                    logger.info(f"Inizio monitoraggio per URI: {self.current_playing_uri}")
                
                if not self.current_playing_uri:
                    await asyncio.sleep(1)
                    continue

                if not _update_active_device():
                    logger.warning("Nessun dispositivo Spotify attivo, monitoraggio in pausa.")
                    await asyncio.sleep(5)
                    continue

                playback_info = self.sp.current_playback()

                # --- LOGICA DI CONTROLLO MIGLIORATA ---
                
                song_has_ended = False
                
                # Caso 1: Non c'è nulla in riproduzione
                if not playback_info or not playback_info.get('item'):
                    logger.info(f"Nessuna riproduzione attiva. Il brano {self.current_playing_uri} è considerato terminato.")
                    song_has_ended = True

                # Caso 2: Sta suonando una canzone diversa da quella che monitoriamo
                elif playback_info['item']['uri'] != self.current_playing_uri:
                    logger.info(f"È partita una nuova canzone. Il brano {self.current_playing_uri} è considerato terminato.")
                    song_has_ended = True
                
                # Caso 3: La canzone è la nostra, ma è in pausa. Non fare nulla.
                elif not playback_info.get('is_playing'):
                    logger.debug(f"Brano {self.current_playing_uri} in pausa. Attendo...")
                    await asyncio.sleep(5)
                    continue
                
                # Caso 4: La canzone è la nostra e sta suonando. Controlliamo il progresso.
                else:
                    track_item = playback_info['item']
                    duration_ms = track_item['duration_ms']
                    progress_ms = playback_info['progress_ms']
                    remaining_ms = duration_ms - progress_ms
                    
                    if remaining_ms < 4000: # Se mancano meno di 4 secondi
                        logger.info(f"Brano {self.current_playing_uri} quasi alla fine.")
                        song_has_ended = True
                    else:
                        # Polling intelligente
                        sleep_time = max(1, min(5, remaining_ms / 1000 / 4))
                        logger.debug(f"Brano in riproduzione. Prossimo controllo tra {sleep_time:.1f}s.")
                        await asyncio.sleep(sleep_time)

                # Se, per uno qualsiasi dei motivi validi, la canzone è terminata, invia la notifica.
                if song_has_ended:
                    logger.info(f"Brano {self.current_playing_uri} terminato. Invio notifica all'agente.")
                    await self.injection_queue.put({
                        "type": "jukebox_notification",
                        "text": "La canzone che stavi ascoltando è finita. Vuoi ascoltare qualcos'altro?"
                    })
                    self.current_playing_uri = None # Resetta per il prossimo brano
                    await asyncio.sleep(2) # Breve pausa dopo la notifica

            except Exception as e:
                logger.error(f"Errore critico nel Jukebox: {e}", exc_info=True)
                self.current_playing_uri = None
                await asyncio.sleep(10)

    def stop(self):
        self.stop_event.set()
        logger.info("Jukebox: segnale di stop ricevuto.")
