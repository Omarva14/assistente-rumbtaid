# main.py
import asyncio
import logging
from dotenv import load_dotenv

# --- CORREZIONE DEFINITIVA ---
# Carichiamo le variabili d'ambiente COME PRIMA COSA ASSOLUTA,
# prima che qualsiasi altro modulo venga importato.
load_dotenv()

# Ora importiamo i nostri moduli, che troveranno le credenziali già caricate
from conversational import ConversationalAgent
from jukebox import Jukebox
from tools import spotify_tools
# Aggiungi l'importazione di spotify_config per accedere alle variabili
import spotify_config # <--- QUESTA È LA RIGA AGGIUNTA IMPORTANTISSIMA
import os
def setup_logging():
    """Configura il logging per l'applicazione."""
    logging.basicConfig(
        level=logging.DEBUG, # Impostato a DEBUG per una diagnostica dettagliata
        format='%(asctime)s - %(name)-15s - %(levelname)-8s - %(message)s'
    )

async def main():
    """Punto di ingresso principale dell'applicazione."""
    logger = logging.getLogger("MAIN")
    logger.info("🚀 Avvio dell'Assistente Capitano... 🚀")

    # --- INIZIALIZZAZIONE SPOTIFY CENTRALIZZATA ---
    # Questo assicura che il client Spotify sia disponibile prima di creare gli altri moduli.
    logger.info("Inizializzazione servizi Spotify...")

    # Invece di chiamare initialize_spotify() senza argomenti,
    # passiamo esplicitamente tutti quelli richiesti, presi da spotify_config.
    if not spotify_tools.initialize_spotify(
        client_id=spotify_config.SPOTIPY_CLIENT_ID,
        client_secret=spotify_config.SPOTIPY_CLIENT_SECRET,
        redirect_uri=spotify_config.SPOTIPY_REDIRECT_URI,
        scope=spotify_config.SCOPE,
        cache_path=spotify_config.CACHE_PATH
    ):
        logger.critical("❌ Impossibile inizializzare Spotify. L'applicazione verrà terminata.")
        return # Termina l'applicazione se Spotify non si inizializza
# --- RIGA DA AGGIUNGERE ---
    # Inizializza il client OpenAI subito dopo Spotify
    spotify_tools.initialize_openai_client(os.getenv("OPENAI_API_KEY"))
    # --- FINE RIGA DA AGGIUNGERE -
    # Ottieni l'istanza del client Spotify che è stata inizializzata e resa disponibile
    # tramite la variabile globale 'sp' in spotify_tools.py.
    sp_client_instance = spotify_tools.get_spotify_client()

    # Crea i canali di comunicazione ("le code")
    injection_queue = asyncio.Queue()
    spotify_polling_queue = asyncio.Queue()

    # Crea le istanze dei nostri moduli, passando i canali.
    # Ora passiamo l'istanza sp_client_instance al Jukebox.
    agent = ConversationalAgent(injection_queue=injection_queue, spotify_polling_queue=spotify_polling_queue)
    jukebox = Jukebox(injection_queue=injection_queue, spotify_polling_queue=spotify_polling_queue, sp_client=sp_client_instance)

    try:
        # Avvia tutto in parallelo
        logger.info("Tutti i moduli pronti. Avvio dei task...")
        await asyncio.gather(
            agent.start(), # Questa chiamata non deve più inizializzare Spotify internamente.
            jukebox.monitor_playback()
        )
    except (asyncio.CancelledError, KeyboardInterrupt):
        logger.info("\nApplicazione interrotta dall'utente.")
    finally:
        # Assicurati che i task vengano fermati in modo pulito quando l'applicazione termina
        agent.stop()
        jukebox.stop()
        logger.info("Applicazione terminata.")

if __name__ == "__main__":
    # La chiamata a load_dotenv() è stata spostata all'inizio del file,
    # prima di qualsiasi importazione per garantire che le variabili siano disponibili subito.
    setup_logging()

    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        # Cattura l'interruzione da tastiera per terminare in modo più gentile se asyncio.run() non lo fa
        pass
