# tools/spotify_tools/__init__.py

import logging
from typing import Optional, Dict, Any, TYPE_CHECKING, List

# Importa i singoli moduli dei tool per esporne le funzioni
from . import auth
from . import playback
from . import search
from . import playlist_artist

# Re-esponi le funzioni di inizializzazione e accesso al client
# Queste sono chiamate da main.py o da altri moduli esterni al pacchetto spotify_tools
initialize_spotify = auth.initialize_spotify
# --- CORREZIONE APPLICATA QUI SOTTO ---
# La funzione viene esposta con il suo nome originale per coerenza
initialize_openai_client = auth.initialize_openai_client
get_spotify_client = auth.get_spotify_client
get_spotify_device_id = auth.get_spotify_device_id
get_user_country = auth.get_user_country
_update_active_device = auth._update_active_device


# Re-esponi tutte le funzioni dei tool che devono essere chiamabili direttamente dall'agente
# Dal modulo playback.py
pause_playback = playback.pause_playback
resume_playback = playback.resume_playback
next_song = playback.next_song
previous_song = playback.previous_song
SetSpotifyVolumePercent = playback.SetSpotifyVolumePercent
ChangeSpotifyVolumeLevel = playback.ChangeSpotifyVolumeLevel

# Dal modulo search.py
play_specific_spotify_track = search.play_specific_spotify_track
add_to_queue = search.add_to_queue
GetCurrentSongInfo = search.GetCurrentSongInfo

# Dal modulo playlist_artist.py
PlaySpotifyPlaylist = playlist_artist.PlaySpotifyPlaylist
PlaySpotifyArtist = playlist_artist.PlaySpotifyArtist
PlayGenre = playlist_artist.PlayGenre
PlayMoodOrActivity = playlist_artist.PlayMoodOrActivity

logger = logging.getLogger("tools.spotify_tools")
